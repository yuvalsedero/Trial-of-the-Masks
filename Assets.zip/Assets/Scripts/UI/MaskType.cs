public enum MaskType
{
    TribeA,
    TribeB,
    TribeC
}
