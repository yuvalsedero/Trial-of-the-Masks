public enum MaskEffectType
{
    None,
    Fire,
    Poison,
    Ice,
    Piercing,
    Ricochet,
    DoubleShot,
    HealthUp,
    StrengthUp,
    SpeedUp
}
