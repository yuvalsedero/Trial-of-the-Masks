public enum DoorDirection
{
    Up,
    Down,
    Left,
    Right
}
