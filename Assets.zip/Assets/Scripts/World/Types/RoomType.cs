public enum RoomType
{
    Spawn,
    Enemy,
    Tribe,
    Boss
}
